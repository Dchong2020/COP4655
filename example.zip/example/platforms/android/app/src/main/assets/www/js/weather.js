const wrapper = document.querySelector(".wrapper"),
inputPart = document.querySelector(".input-part"),
infoTxt = inputPart.querySelector(".info-txt"),
inputField = inputPart.querySelector("input"),
locationBtn = inputPart.querySelector("button"),
weatherPart = wrapper.querySelector(".weather-part"),
wIcon = weatherPart.querySelector("img"),
arrowBack = wrapper.querySelector("header i");

let api;

inputField.addEventListener("keyup", e =>{
    // if user pressed enter btn and input value is not empty
    if(e.key == "Enter" && inputField.value != ""){
        requestApi(inputField.value);
    }
});

locationBtn.addEventListener("click", () =>{
    if(navigator.geolocation){ // if browser support geolocation api
        navigator.geolocation.getCurrentPosition(onSuccess, onError);
    }else{
        alert("Your browser not support geolocation api");
    }
});

function requestApi(city){
    api = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=imperial&appid=d6a5bb9387487e1e1a124d41eb1d582e`;
    fetchData();
}

function onSuccess(position){
    const {latitude, longitude} = position.coords; // getting lat and lon of the user device from coords obj
    api = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=imperial&appid=d6a5bb9387487e1e1a124d41eb1d582e`;
    fetchData();
}

function onError(error){
    // if any error occur while getting user location then we'll show it in infoText
    infoTxt.innerText = error.message;
    infoTxt.classList.add("error");
}

function fetchData(){
    infoTxt.innerText = "Getting weather details...";
    infoTxt.classList.add("pending");
    // getting api response and returning it with parsing into js obj and in another
    // then function calling weatherDetails function with passing api result as an argument
    fetch(api).then(res => res.json()).then(result => weatherDetails(result)).catch(() =>{
        infoTxt.innerText = "Something went wrong";
        infoTxt.classList.replace("pending", "error");
    });
}

function weatherDetails(info){
    if(info.cod == "404"){ // if user entered city name isn't valid
        infoTxt.classList.replace("pending", "error");
        infoTxt.innerText = `${inputField.value} isnt a valid city name`;
    }else{
        //getting required properties value from the whole weather information
        const city = info.name;
        const country = info.sys.country;
        const wind = info.wind.speed;
        const cloud = info.clouds.all;
        const wind_dir = info.wind.deg;
        const {description, id} = info.weather[0];
        const {temp, feels_like, humidity, pressure,temp_min,temp_max,} = info.main;






        // using custom weather icon according to the id which api gives to us
        if(id == 800){
            wIcon.src = "img/clear.svg";
        }else if(id >= 200 && id <= 232){
            wIcon.src = "img/storm.svg";
        }else if(id >= 600 && id <= 622){
            wIcon.src = "img/snow.svg";
        }else if(id >= 701 && id <= 781){
            wIcon.src = "img/haze.svg";
        }else if(id >= 801 && id <= 804){
            wIcon.src = "img/cloud.svg";
        }else if((id >= 500 && id <= 531) || (id >= 300 && id <= 321)){
            wIcon.src = "img/rain.svg";
        }

        //passing a particular weather info to a particular element
        weatherPart.querySelector(".temp .numb").innerText = Math.floor(temp);
        weatherPart.querySelector(".weather").innerText = description;
        weatherPart.querySelector(".location span").innerText = `${city}, ${country}`;
        weatherPart.querySelector(".temp .numb-2").innerText = Math.floor(feels_like);
        weatherPart.querySelector(".humidity span").innerText = `${humidity}%`;
        weatherPart.querySelector(".press .numb-2").innerText = `${pressure} hPa`;
        weatherPart.querySelector(".min .numb-2").innerText = Math.floor(temp_min);
        weatherPart.querySelector(".max .numb-2").innerText = Math.floor(temp_max);
        weatherPart.querySelector(".speed .numb-2").innerText = Math.floor(wind);
        weatherPart.querySelector(".dir .numb-2").innerText = Math.floor(wind_dir);
        weatherPart.querySelector(".cloud .numb-2").innerText = Math.floor(cloud);
        infoTxt.classList.remove("pending", "error");
        infoTxt.innerText = "";
        inputField.value = "";
        wrapper.classList.add("active");
    }
}

arrowBack.addEventListener("click", ()=>{
    wrapper.classList.remove("active");
});