const firebaseConfig = {
  apiKey: "AIzaSyCXkPCrm3IJa_J-ZJf61p39weMBdXjMyIo",
  authDomain: "web-login-75219.firebaseapp.com",
  projectId: "web-login-75219",
  storageBucket: "web-login-75219.appspot.com",
  messagingSenderId: "286420720534",
  appId: "1:286420720534:web:aa41821cc7fcdb406edbb7",
  measurementId: "G-1CPE1Z6MV3"
};
